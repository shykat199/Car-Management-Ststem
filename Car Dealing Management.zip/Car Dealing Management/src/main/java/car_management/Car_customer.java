package car_management;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Car_customer {
	
	//Data Member
	private String customerIDString;
	private String firstNameString;
	private String surNameString;
	private String addressString;
	private String postCodeString;
	private String townString;
	private String proveofIdString;
	private Double depositStringDouble;
	private Double downPaymentDouble;
	
	
	
	/**
	 * Accessor Function
	 * @return
	 */
	public String getCustomerIDString() {
		return customerIDString;
	}
	public void setCustomerIDString(String customerIDString) {
		this.customerIDString = customerIDString;
	}
	public String getFirstNameString() {
		return firstNameString;
	}
	public void setFirstNameString(String firstNameString) {
		this.firstNameString = firstNameString;
	}
	public String getSurNameString() {
		return surNameString;
	}
	public void setSurNameString(String surNameString) {
		this.surNameString = surNameString;
	}
	public String getAddressString() {
		return addressString;
	}
	public void setAddressString(String addressString) {
		this.addressString = addressString;
	}
	public String getPostCodeString() {
		return postCodeString;
	}
	public void setPostCodeString(String postCodeString) {
		this.postCodeString = postCodeString;
	}
	public String getTownString() {
		return townString;
	}
	public void setTownString(String townString) {
		this.townString = townString;
	}
	public String getProveofIdString() {
		return proveofIdString;
	}
	public void setProveofIdString(String proveofIdString) {
		this.proveofIdString = proveofIdString;
	}
	public Double getDepositStringDouble() {
		return depositStringDouble;
	}
	public void setDepositStringDouble(Double depositStringDouble) {
		this.depositStringDouble = depositStringDouble;
	}
	public Double getDownPaymentDouble() {
		return downPaymentDouble;
	}
	public void setDownPaymentDouble(Double downPaymentDouble) {
		this.downPaymentDouble = downPaymentDouble;
	}
	
	private JFrame frame;
	
	public void iExitSystem() {
		frame=new JFrame("Exit");
		if (JOptionPane.showConfirmDialog(frame, "Confirm if you want to exit","Car management system",JOptionPane.YES_NO_OPTION)==JOptionPane.YES_NO_OPTION) {
			
			System.exit(0);
		}
	}
	
}
