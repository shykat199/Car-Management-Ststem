package car_management;

import java.awt.EventQueue;
import java.text.*;
import java.awt.print.*;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;

import com.mysql.cj.x.protobuf.MysqlxNotice.Warning.Level;

import java.awt.Color;
import java.awt.Component;
import java.awt.SystemColor;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.UIManager;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import java.awt.event.ActionListener;
import java.awt.print.PrinterException;
import java.lang.System.Logger;
import java.security.PublicKey;
import java.util.Iterator;
import java.awt.event.ActionEvent;

public class Car_management {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_10;
	private JTextField textField_11;
	private JTextField tax;
	private JTextField subTotal;
	private JTextField total;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Car_management window = new Car_management();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Car_management() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setFont(new Font("Tahoma", Font.PLAIN, 16));
		frame.getContentPane().setBackground(UIManager.getColor("Button.light"));
		frame.setBounds(100, 100, 1148, 788);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 11, 1114, 88);
		panel.setBackground(new Color(148, 0, 211));
		panel.setBorder(new LineBorder(new Color(0, 255, 255), 10));
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Car Management System");
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Sitka Text", Font.BOLD | Font.ITALIC, 50));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(215, 22, 719, 56);
		panel.add(lblNewLabel);
		
		final JPanel Details_panal = new JPanel();
		Details_panal.setBackground(new Color(192, 192, 192));
		Details_panal.setBounds(10, 122, 729, 224);
		Details_panal.setBorder(new LineBorder(new Color(255, 0, 255), 10, true));
		frame.getContentPane().add(Details_panal);
		Details_panal.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Customer Details");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		Border blackline = BorderFactory.createLineBorder(Color.black);
		//blackline.setSiz
		lblNewLabel_1.setBounds(24, 21, 154, 30);
		lblNewLabel_1.setBorder(new LineBorder(new Color(255, 255, 255), 3));
		Details_panal.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Customer ID");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_2.setBounds(24, 75, 79, 30);
		Details_panal.add(lblNewLabel_2);
		
		textField = new JTextField();
		textField.setBounds(134, 81, 101, 30);
		Details_panal.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(134, 122, 101, 30);
		Details_panal.add(textField_1);
		
		JLabel lblNewLabel_2_1 = new JLabel("First Name");
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_2_1.setBounds(24, 116, 79, 30);
		Details_panal.add(lblNewLabel_2_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(134, 163, 101, 30);
		Details_panal.add(textField_2);
		
		JLabel lblNewLabel_2_2 = new JLabel("Surname\r\n");
		lblNewLabel_2_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_2_2.setBounds(24, 162, 79, 30);
		Details_panal.add(lblNewLabel_2_2);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(370, 81, 336, 30);
		Details_panal.add(textField_3);
		
		JLabel lblNewLabel_2_3 = new JLabel("Address");
		lblNewLabel_2_3.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_2_3.setBounds(260, 75, 79, 30);
		Details_panal.add(lblNewLabel_2_3);
		
		JLabel lblNewLabel_2_1_1 = new JLabel("Post Code\r\n");
		lblNewLabel_2_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_2_1_1.setBounds(260, 116, 79, 30);
		Details_panal.add(lblNewLabel_2_1_1);
		
		JLabel lblNewLabel_2_2_1 = new JLabel("Town");
		lblNewLabel_2_2_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_2_2_1.setBounds(260, 162, 79, 30);
		Details_panal.add(lblNewLabel_2_2_1);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(370, 122, 101, 30);
		Details_panal.add(textField_4);
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(370, 163, 101, 30);
		Details_panal.add(textField_5);
		
		textField_6 = new JTextField();
		textField_6.setColumns(10);
		textField_6.setBounds(605, 122, 101, 30);
		Details_panal.add(textField_6);
		
		JLabel lblNewLabel_2_1_1_1 = new JLabel("Down Payment");
		lblNewLabel_2_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_2_1_1_1.setBounds(495, 122, 100, 30);
		Details_panal.add(lblNewLabel_2_1_1_1);
		
		JLabel lblNewLabel_2_2_1_1 = new JLabel("Deposit");
		lblNewLabel_2_2_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_2_2_1_1.setBounds(495, 168, 79, 30);
		Details_panal.add(lblNewLabel_2_2_1_1);
		
		textField_7 = new JTextField();
		textField_7.setColumns(10);
		textField_7.setBounds(605, 169, 101, 30);
		Details_panal.add(textField_7);
		
		final JComboBox comboBox = new JComboBox();
		comboBox.setBackground(Color.WHITE);
		comboBox.setFont(new Font("Tahoma", Font.BOLD, 16));
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Prove Of Id", "Driving Licence", "Car Insurance"}));
		comboBox.setBounds(495, 18, 211, 36);
		Details_panal.add(comboBox);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(749, 122, 375, 499);
		panel_2.setBorder(new LineBorder(new Color(255, 0, 255), 10));
		frame.getContentPane().add(panel_2);
		panel_2.setLayout(null);
		
		final JTextArea textArea = new JTextArea();
		textArea.setBackground(new Color(220, 220, 220));
		textArea.setBounds(10, 11, 355, 477);
		panel_2.add(textArea);
		
		JPanel panel_2_1 = new JPanel();
		panel_2_1.setBackground(new Color(192, 192, 192));
		panel_2_1.setLayout(null);
		panel_2_1.setBorder(new LineBorder(new Color(255, 0, 255), 10));
		panel_2_1.setBounds(10, 357, 364, 163);
		frame.getContentPane().add(panel_2_1);
		
		final JCheckBox chckbxGlobalPositioningSystem = new JCheckBox("Global Positioning System");
		chckbxGlobalPositioningSystem.setFont(new Font("Tahoma", Font.BOLD, 13));
		chckbxGlobalPositioningSystem.setBackground(Color.LIGHT_GRAY);
		chckbxGlobalPositioningSystem.setBounds(16, 109, 196, 36);
		panel_2_1.add(chckbxGlobalPositioningSystem);
		chckbxGlobalPositioningSystem.setSelected(true);
		
		final JCheckBox chckbxNewCheckBox_2_1 = new JCheckBox("Leather Interio");
		chckbxNewCheckBox_2_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		chckbxNewCheckBox_2_1.setBackground(Color.LIGHT_GRAY);
		chckbxNewCheckBox_2_1.setBounds(16, 65, 127, 36);
		panel_2_1.add(chckbxNewCheckBox_2_1);
		chckbxNewCheckBox_2_1.setSelected(true);

		
		final JCheckBox chckbxNewCheckBox_2_2 = new JCheckBox("Stereo System");
		chckbxNewCheckBox_2_2.setFont(new Font("Tahoma", Font.BOLD, 13));
		chckbxNewCheckBox_2_2.setBackground(Color.LIGHT_GRAY);
		chckbxNewCheckBox_2_2.setBounds(16, 15, 127, 36);
		panel_2_1.add(chckbxNewCheckBox_2_2);
		chckbxNewCheckBox_2_2.setSelected(true);

		
		final JCheckBox chckbxNewCheckBox_2_2_1 = new JCheckBox("Standard");
		chckbxNewCheckBox_2_2_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		chckbxNewCheckBox_2_2_1.setBackground(Color.LIGHT_GRAY);
		chckbxNewCheckBox_2_2_1.setBounds(230, 15, 97, 36);
		panel_2_1.add(chckbxNewCheckBox_2_2_1);
		chckbxNewCheckBox_2_2_1.setSelected(true);

		
		final JCheckBox chckbxNewCheckBox_2_1_1 = new JCheckBox("Modified");
		chckbxNewCheckBox_2_1_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		chckbxNewCheckBox_2_1_1.setBackground(Color.LIGHT_GRAY);
		chckbxNewCheckBox_2_1_1.setBounds(230, 65, 97, 36);
		panel_2_1.add(chckbxNewCheckBox_2_1_1);
		chckbxNewCheckBox_2_1_1.setSelected(true);

		
		final JPanel panel_2_1_1 = new JPanel();
		panel_2_1_1.setBackground(new Color(192, 192, 192));
		panel_2_1_1.setLayout(null);
		panel_2_1_1.setBorder(new LineBorder(new Color(255, 0, 255), 10));
		panel_2_1_1.setBounds(10, 524, 364, 106);
		frame.getContentPane().add(panel_2_1_1);
		
		final JComboBox comboBox_CarBox = new JComboBox();
		comboBox_CarBox.setModel(new DefaultComboBoxModel(new String[] {"Select a Car", "Ford", "Bmw", "Porche", "Aston_Martin"}));
		comboBox_CarBox.setBounds(88, 20, 201, 24);
		panel_2_1_1.add(comboBox_CarBox);
		comboBox_CarBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				if (comboBox_CarBox.getSelectedItem().equals("Select a Car")) {
					textField_9.setText(""); //cost
					textField_8.setText(""); //year
				}
				
				if (comboBox_CarBox.getSelectedItem().equals("Ford")) {
					String carString=String.format("$%.2f",Ford);
					textField_9.setText(carString); //cost
					textField_8.setText("2018"); //year
				}
				
				if (comboBox_CarBox.getSelectedItem().equals("Bmw")) {
					String carString=String.format("$%.2f",Bmw);
					textField_9.setText(carString); //cost
					textField_8.setText("2015");     //year
				}
				
				if (comboBox_CarBox.getSelectedItem().equals("Porche")) {
					String carString=String.format("$%.2f",Porche);
					textField_9.setText(carString); //cost
					textField_8.setText("2019"); //year
				}
				
				if (comboBox_CarBox.getSelectedItem().equals("Aston_Martin")) {
					String carString=String.format("$%.2f",Aston_Martin);
					textField_9.setText(carString); //cost
					textField_8.setText("2020"); //year
				}
			}
		});
	
		
		JLabel lblNewLabel_3 = new JLabel("Year");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_3.setBounds(22, 55, 46, 31);
		panel_2_1_1.add(lblNewLabel_3);
		
		textField_8 = new JTextField();
		textField_8.setBounds(66, 55, 97, 31);
		panel_2_1_1.add(textField_8);
		textField_8.setColumns(10);
		
		textField_9 = new JTextField();
		textField_9.setColumns(10);
		textField_9.setBounds(238, 56, 102, 31);
		panel_2_1_1.add(textField_9);
		
		JLabel lblNewLabel_3_1 = new JLabel("Cost");
		lblNewLabel_3_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_3_1.setBounds(196, 55, 46, 31);
		panel_2_1_1.add(lblNewLabel_3_1);
		
		final JPanel panel_2_1_1_1 = new JPanel();
		panel_2_1_1_1.setBackground(new Color(192, 192, 192));
		panel_2_1_1_1.setLayout(null);
		panel_2_1_1_1.setBorder(new LineBorder(new Color(255, 0, 255), 10));
		panel_2_1_1_1.setBounds(10, 632, 364, 106);
		frame.getContentPane().add(panel_2_1_1_1);
		
		
		final JComboBox car_trade = new JComboBox();
		
		car_trade.setModel(new DefaultComboBoxModel(new String[] {"Trade In ", "1 - 5000", "5001 - 20000", "20001 - 50000", "50001 - 100000", "100001 - 500000"}));
		car_trade.setBounds(22, 36, 143, 24);
		panel_2_1_1_1.add(car_trade);
		car_trade.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				/**
				 * private String trade_in_1="1 - 5000"; private String trade_in_2="5001 -
				 * 20000"; private String trade_in_3="20001 - 50000"; private String
				 * trade_in_4="50001 - 100000"; private String trade_in_5="100001 - 500000";
				 */
				
				if (car_trade.getSelectedItem().equals( "Trade In ")) {
					textField_11.setText("");
					textField_10.setText("");
				}
				
				if (car_trade.getSelectedItem().equals( "1 - 5000")) {
					textField_11.setText("10000 $");
					textField_10.setText("2018");
				}
				if (car_trade.getSelectedItem().equals("5001 - 20000")) {
					textField_11.setText("18000 $");
					textField_10.setText("2019");
				}
				if (car_trade.getSelectedItem().equals("20001 - 50000")) {
					textField_11.setText("10500 $");
					textField_10.setText("2015");
				}
				if (car_trade.getSelectedItem().equals("50001 - 100000")) {
					textField_11.setText("18000 $");
					textField_10.setText("2019");
				}
				if (car_trade.getSelectedItem().equals("100001 - 500000")) {
					textField_11.setText("18500 $");
					textField_10.setText("2020");
				}
			}
		});
		
		
		JLabel lblNewLabel_3_2 = new JLabel("Year");
		lblNewLabel_3_2.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_3_2.setBounds(187, 11, 46, 31);
		panel_2_1_1_1.add(lblNewLabel_3_2);
		
		textField_10 = new JTextField();
		textField_10.setColumns(10);
		textField_10.setBounds(243, 12, 97, 31);
		panel_2_1_1_1.add(textField_10);
		
		JLabel lblNewLabel_3_1_1 = new JLabel("Cost");
		lblNewLabel_3_1_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_3_1_1.setBounds(187, 64, 46, 31);
		panel_2_1_1_1.add(lblNewLabel_3_1_1);
		
		textField_11 = new JTextField();
		textField_11.setColumns(10);
		textField_11.setBounds(243, 64, 97, 31);
		panel_2_1_1_1.add(textField_11);
		
		final JPanel CostPanal = new JPanel();
		CostPanal.setBackground(new Color(192, 192, 192));
		CostPanal.setLayout(null);
		CostPanal.setBorder(new LineBorder(new Color(255, 0, 255), 10));
		CostPanal.setBounds(384, 357, 355, 264);
		frame.getContentPane().add(CostPanal);
		
		JLabel lblNewLabel_2_4 = new JLabel("Tax");
		lblNewLabel_2_4.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_2_4.setBounds(31, 29, 100, 46);
		CostPanal.add(lblNewLabel_2_4);
		
		tax = new JTextField();
		tax.setColumns(10);
		tax.setBounds(141, 29, 181, 46);
		CostPanal.add(tax);
		
		subTotal = new JTextField();
		subTotal.setColumns(10);
		subTotal.setBounds(141, 104, 181, 46);
		CostPanal.add(subTotal);
		
		JLabel lblNewLabel_2_4_1 = new JLabel("Sub Total");
		lblNewLabel_2_4_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_2_4_1.setBounds(31, 104, 100, 46);
		CostPanal.add(lblNewLabel_2_4_1);
		
		total = new JTextField();
		total.setColumns(10);
		total.setBounds(141, 182, 181, 46);
		CostPanal.add(total);
		
		JLabel lblNewLabel_2_4_2 = new JLabel("Total");
		lblNewLabel_2_4_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_2_4_2.setBounds(31, 182, 100, 46);
		CostPanal.add(lblNewLabel_2_4_2);
		
		JPanel panel_2_1_1_1_1 = new JPanel();
		panel_2_1_1_1_1.setBackground(new Color(192, 192, 192));
		panel_2_1_1_1_1.setLayout(null);
		panel_2_1_1_1_1.setBorder(new LineBorder(new Color(255, 0, 255), 10));
		panel_2_1_1_1_1.setBounds(384, 632, 740, 106);
		frame.getContentPane().add(panel_2_1_1_1_1);
		
		JButton Exit_btn = new JButton("Exit");
		Exit_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Car_customer iExit=new Car_customer();
				
				try {
					iExit.iExitSystem();
				} catch (Exception e2) {
					// TODO: handle exception
					JOptionPane.showConfirmDialog(null, "Confirm if you want to exit");
				}
				
			}
		});
		Exit_btn.setForeground(Color.WHITE);
		Exit_btn.setBackground(SystemColor.textHighlight);
		Exit_btn.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		Exit_btn.setBounds(567, 24, 150, 57);
		panel_2_1_1_1_1.add(Exit_btn);
		
		JButton Reset_btn = new JButton("Reset");
		Reset_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				JTextField clearTextField = null;
				JComboBox comboBox=null;

				try {			
					for (Component c : panel_2_1_1.getComponents()) {
						if (c.getClass().toString().contains("javax.swing.JComboBox")) {
							comboBox = (JComboBox) c;
							comboBox.setSelectedIndex(0);
							chckbxGlobalPositioningSystem.setSelected(true);
							chckbxNewCheckBox_2_1.setSelected(true);
							chckbxNewCheckBox_2_2.setSelected(true);
							chckbxNewCheckBox_2_2_1.setSelected(true);
							chckbxNewCheckBox_2_1_1.setSelected(true);
						}
					}
					
					for (Component c : panel_2_1_1_1.getComponents()) {
						if (c.getClass().toString().contains("javax.swing.JComboBox")) {
							comboBox = (JComboBox) c;
							comboBox.setSelectedIndex(0);
						}
					}
					
					for (Component c : CostPanal.getComponents()) {
						if (c.getClass().toString().contains("javax.swing.JTextField")) {
							clearTextField = (JTextField) c;
							clearTextField.setText("");
							textArea.setText("");
						}
					}

					for (Component c : Details_panal.getComponents()) {
						if (c.getClass().toString().contains("javax.swing.JTextField")) {
							clearTextField = (JTextField) c;
							clearTextField.setText("");
						}
					}

					for (Component c : panel_2_1_1.getComponents()) {
						if (c.getClass().toString().contains("javax.swing.JTextField")) {
							clearTextField = (JTextField) c;
							clearTextField.setText("");
						}
					}

					for (Component c : panel_2_1_1_1.getComponents()) {
						if (c.getClass().toString().contains("javax.swing.JTextField")) {
							clearTextField = (JTextField) c;
							clearTextField.setText("");
						}
					}

				} catch (Exception e2) {

					JOptionPane.showConfirmDialog(null, "Confirm if you want to reset");

				}

			}
		});
		Reset_btn.setForeground(Color.WHITE);
		Reset_btn.setBackground(SystemColor.textHighlight);
		Reset_btn.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		Reset_btn.setBounds(400, 24, 150, 57);
		panel_2_1_1_1_1.add(Reset_btn);
		
		JButton Print_btn = new JButton("Print");
		Print_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textArea.append("\tCar Dealer Management Sysyem"+"\n"+
			"-----------------------------------------------------------------------"+"\n");
				textArea.append("Customer Id"+"\t\t\t"+textField.getText()+"\n");
				textArea.append("Firstname"+"\t\t\t"+textField_1.getText()+"\n");
				textArea.append("Surname"+"\t\t\t"+textField_2.getText()+"\n");
				textArea.append("Address"+"\t\t\t"+textField_3.getText()+"\n");
				textArea.append("Post Code"+"\t\t\t"+textField_4.getText()+"\n");
				textArea.append("Prove of Id"+"\t\t\t"+comboBox.getSelectedItem()+"\n");
				textArea.append("Town"+"\t\t\t"+textField_5.getText()+"\n");
				textArea.append("---------------------------------------------------------");
				textArea.append("Deposit"+"\t\t\t"+textField_7.getText()+"\n");
				textArea.append("Down Payment"+"\t\t\t"+textField_6.getText()+"\n");
				textArea.append("Type of Car"+"\t\t\t"+comboBox_CarBox.getSelectedItem()+"\n");
				
				textArea.append("Year"+"\t\t\t"+textField_8.getText()+"\n");
				textArea.append("Cost"+"\t\t\t"+textField_9.getText()+"\n");
				textArea.append("------------------------------------------------------------"+"\n");
				textArea.append("Tax"+"\t\t\t"+tax.getText()+"\n");
				textArea.append("Subtotal"+"\t\t\t"+subTotal.getText()+"\n");
				textArea.append("Total Payment"+"\t\t\t"+total.getText()+"\n");
				textArea.append("-------------------------------------------------------------"+"\n");


				
				
				 try {
					 textArea.print();
				} catch (PrinterException e2) {
					
					//Logger.getLogger(Car_management.class.getName().log(Level.ERROR_VALUE,null,e2));
				}
			}
			
			private void formWindowActivated(java.awt.event.WindowEvent evt) {
				Car car=new Car();
				car_trade.addItem(car.getTrade_in_1());
				car_trade.addItem(car.getTrade_in_2());
				car_trade.addItem(car.getTrade_in_3());
				car_trade.addItem(car.getTrade_in_4());
				car_trade.addItem(car.getTrade_in_5());
				
				
				chckbxGlobalPositioningSystem.setSelected(true);
				chckbxNewCheckBox_2_1.setSelected(true);
				chckbxNewCheckBox_2_2.setSelected(true);
				chckbxNewCheckBox_2_2_1.setSelected(true);
				chckbxNewCheckBox_2_1_1.setSelected(true);

			}
		});
		Print_btn.setForeground(Color.WHITE);
		Print_btn.setBackground(SystemColor.textHighlight);
		Print_btn.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		Print_btn.setBounds(220, 24, 150, 57);
		panel_2_1_1_1_1.add(Print_btn);
		
		JButton Total_btn = new JButton("Total");
		Total_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Car_Accessor Accessor =new Car_Accessor();	
				
				if (comboBox_CarBox.getSelectedItem().equals("Ford") && comboBox_CarBox.getSelectedItem().equals("Ford") ) {
					String isubTotalString=String.format("$%.2f",Ford+Accessor.GetAmount());
					String iTax=String.format("$%.2f",cFindTax(Ford+Accessor.GetAmount()));
					String iTotal=String.format("$%.2f",Ford+Accessor.GetAmount()+cFindTax(Ford+Accessor.GetAmount()));

					tax.setText(iTax); //tax
					subTotal.setText(isubTotalString); //sub total
					total.setText(iTotal); //total
				}
				
				if (comboBox_CarBox.getSelectedItem().equals("Bmw") && comboBox_CarBox.getSelectedItem().equals("Bmw") ) {
					String isubTotalString=String.format("$%.2f",Bmw+Accessor.GetAmount());
					String iTax=String.format("$%.2f",cFindTax(Bmw+Accessor.GetAmount()));
					String iTotal=String.format("$%.2f",Bmw+Accessor.GetAmount()+cFindTax(Ford+Accessor.GetAmount()));

					tax.setText(iTax); //tax
					subTotal.setText(isubTotalString); //sub total
					total.setText(iTotal); //total
				}
				
				if (comboBox_CarBox.getSelectedItem().equals("Porche") && comboBox_CarBox.getSelectedItem().equals("Porche") ) {
					String isubTotalString=String.format("$%.2f",Porche+Accessor.GetAmount());
					String iTax=String.format("$%.2f",cFindTax(Porche+Accessor.GetAmount()));
					String iTotal=String.format("$%.2f",Porche+Accessor.GetAmount()+cFindTax(Ford+Accessor.GetAmount()));

					tax.setText(iTax); //tax
					subTotal.setText(isubTotalString); //sub total
					total.setText(iTotal); //total
				}
				
				if (comboBox_CarBox.getSelectedItem().equals("Aston_Martin") && comboBox_CarBox.getSelectedItem().equals("Aston_Martin") ) {
					String isubTotalString=String.format("$%.2f",Aston_Martin+Accessor.GetAmount());
					String iTax=String.format("$%.2f",cFindTax(Aston_Martin+Accessor.GetAmount()));
					String iTotal=String.format("$%.2f",Aston_Martin+Accessor.GetAmount()+cFindTax(Ford+Accessor.GetAmount()));

					tax.setText(iTax); //tax
					subTotal.setText(isubTotalString); //sub total
					total.setText(iTotal); //total
				}
				
				/**
				 *  car trade 1 - 5000
				 */
				
				if (comboBox_CarBox.getSelectedItem().equals("Ford") && car_trade.getSelectedItem().equals("1 - 5000") ) {
					Ford=Ford-5000;
					String isubTotalString=String.format("$%.2f",Ford+Accessor.GetAmount());
					String iTax=String.format("$%.2f",cFindTax(Ford+Accessor.GetAmount()));
					String iTotal=String.format("$%.2f",Ford+Accessor.GetAmount()+cFindTax(Ford+Accessor.GetAmount()));

					tax.setText(iTax); //tax
					subTotal.setText(isubTotalString); //sub total
					total.setText(iTotal); //total
				}
				
				if (comboBox_CarBox.getSelectedItem().equals("Bmw") && car_trade.getSelectedItem().equals("1 - 5000") ) {
					Bmw=Bmw-5000;
					String isubTotalString=String.format("$%.2f",Bmw+Accessor.GetAmount());
					String iTax=String.format("$%.2f",cFindTax(Bmw+Accessor.GetAmount()));
					String iTotal=String.format("$%.2f",Bmw+Accessor.GetAmount()+cFindTax(Ford+Accessor.GetAmount()));

					tax.setText(iTax); //tax
					subTotal.setText(isubTotalString); //sub total
					total.setText(iTotal); //total
				}
				
				if (comboBox_CarBox.getSelectedItem().equals("Porche") && car_trade.getSelectedItem().equals("1 - 5000") ) {
					Porche=Porche-5000;
					String isubTotalString=String.format("$%.2f",Porche+Accessor.GetAmount());
					String iTax=String.format("$%.2f",cFindTax(Porche+Accessor.GetAmount()));
					String iTotal=String.format("$%.2f",Porche+Accessor.GetAmount()+cFindTax(Ford+Accessor.GetAmount()));

					tax.setText(iTax); //tax
					subTotal.setText(isubTotalString); //sub total
					total.setText(iTotal); //total
				}
				
				if (comboBox_CarBox.getSelectedItem().equals("Aston_Martin") && car_trade.getSelectedItem().equals("1 - 5000") ) {
					Aston_Martin=Aston_Martin-5000;
					String isubTotalString=String.format("$%.2f",Aston_Martin+Accessor.GetAmount());
					String iTax=String.format("$%.2f",cFindTax(Aston_Martin+Accessor.GetAmount()));
					String iTotal=String.format("$%.2f",Aston_Martin+Accessor.GetAmount()+cFindTax(Ford+Accessor.GetAmount()));

					tax.setText(iTax); //tax
					subTotal.setText(isubTotalString); //sub total
					total.setText(iTotal); //total
				}
				
				/**
				 * car trade 5001 - 20000
				 */
				
				if (comboBox_CarBox.getSelectedItem().equals("Ford") && car_trade.getSelectedItem().equals("5001 - 20000") ) {
					Ford=Ford-2500;
					String isubTotalString=String.format("$%.2f",Ford+Accessor.GetAmount());
					String iTax=String.format("$%.2f",cFindTax(Ford+Accessor.GetAmount()));
					String iTotal=String.format("$%.2f",Ford+Accessor.GetAmount()+cFindTax(Ford+Accessor.GetAmount()));

					tax.setText(iTax); //tax
					subTotal.setText(isubTotalString); //sub total
					total.setText(iTotal); //total
				}
				
				if (comboBox_CarBox.getSelectedItem().equals("Bmw") && car_trade.getSelectedItem().equals("5001 - 20000") ) {
					Bmw=Bmw-2500;
					String isubTotalString=String.format("$%.2f",Bmw+Accessor.GetAmount());
					String iTax=String.format("$%.2f",cFindTax(Bmw+Accessor.GetAmount()));
					String iTotal=String.format("$%.2f",Bmw+Accessor.GetAmount()+cFindTax(Ford+Accessor.GetAmount()));

					tax.setText(iTax); //tax
					subTotal.setText(isubTotalString); //sub total
					total.setText(iTotal); //total
				}
				
				if (comboBox_CarBox.getSelectedItem().equals("Porche") && car_trade.getSelectedItem().equals("5001 - 20000") ) {
					Porche=Porche-2500;
					String isubTotalString=String.format("$%.2f",Porche+Accessor.GetAmount());
					String iTax=String.format("$%.2f",cFindTax(Porche+Accessor.GetAmount()));
					String iTotal=String.format("$%.2f",Porche+Accessor.GetAmount()+cFindTax(Ford+Accessor.GetAmount()));

					tax.setText(iTax); //tax
					subTotal.setText(isubTotalString); //sub total
					total.setText(iTotal); //total
				}
				
				if (comboBox_CarBox.getSelectedItem().equals("Aston_Martin") && car_trade.getSelectedItem().equals("5001 - 20000") ) {
					Aston_Martin=Aston_Martin-2500;
					String isubTotalString=String.format("$%.2f",Aston_Martin+Accessor.GetAmount());
					String iTax=String.format("$%.2f",cFindTax(Aston_Martin+Accessor.GetAmount()));
					String iTotal=String.format("$%.2f",Aston_Martin+Accessor.GetAmount()+cFindTax(Ford+Accessor.GetAmount()));

					tax.setText(iTax); //tax
					subTotal.setText(isubTotalString); //sub total
					total.setText(iTotal); //total
				}
				
				
				/**
				 * car trade 20001 - 50000
				 */
				if (comboBox_CarBox.getSelectedItem().equals("Ford") && car_trade.getSelectedItem().equals("20001 - 50000") ) {
					Ford=Ford-2000;
					String isubTotalString=String.format("$%.2f",Ford+Accessor.GetAmount());
					String iTax=String.format("$%.2f",cFindTax(Ford+Accessor.GetAmount()));
					String iTotal=String.format("$%.2f",Ford+Accessor.GetAmount()+cFindTax(Ford+Accessor.GetAmount()));

					tax.setText(iTax); //tax
					subTotal.setText(isubTotalString); //sub total
					total.setText(iTotal); //total
				}
				
				if (comboBox_CarBox.getSelectedItem().equals("Bmw") && car_trade.getSelectedItem().equals("20001 - 50000") ) {
					Bmw=Bmw-2000;
					String isubTotalString=String.format("$%.2f",Bmw+Accessor.GetAmount());
					String iTax=String.format("$%.2f",cFindTax(Bmw+Accessor.GetAmount()));
					String iTotal=String.format("$%.2f",Bmw+Accessor.GetAmount()+cFindTax(Ford+Accessor.GetAmount()));

					tax.setText(iTax); //tax
					subTotal.setText(isubTotalString); //sub total
					total.setText(iTotal); //total
				}
				
				if (comboBox_CarBox.getSelectedItem().equals("Porche") && car_trade.getSelectedItem().equals("20001 - 50000") ) {
					Porche=Porche-2000;
					String isubTotalString=String.format("$%.2f",Porche+Accessor.GetAmount());
					String iTax=String.format("$%.2f",cFindTax(Porche+Accessor.GetAmount()));
					String iTotal=String.format("$%.2f",Porche+Accessor.GetAmount()+cFindTax(Ford+Accessor.GetAmount()));

					tax.setText(iTax); //tax
					subTotal.setText(isubTotalString); //sub total
					total.setText(iTotal); //total
				}
				
				if (comboBox_CarBox.getSelectedItem().equals("Aston_Martin") && car_trade.getSelectedItem().equals("20001 - 50000"))  {
					Aston_Martin=Aston_Martin-2000;
					String isubTotalString=String.format("$%.2f",Aston_Martin+Accessor.GetAmount());
					String iTax=String.format("$%.2f",cFindTax(Aston_Martin+Accessor.GetAmount()));
					String iTotal=String.format("$%.2f",Aston_Martin+Accessor.GetAmount()+cFindTax(Ford+Accessor.GetAmount()));

					tax.setText(iTax); //tax
					subTotal.setText(isubTotalString); //sub total
					total.setText(iTotal); //total
				}
			
			/**
			 * car trade 50001 - 100000
			 */
			if (comboBox_CarBox.getSelectedItem().equals("Ford") && car_trade.getSelectedItem().equals("50001 - 100000") ) {
				Ford=Ford-1200;
				String isubTotalString=String.format("$%.2f",Ford+Accessor.GetAmount());
				String iTax=String.format("$%.2f",cFindTax(Ford+Accessor.GetAmount()));
				String iTotal=String.format("$%.2f",Ford+Accessor.GetAmount()+cFindTax(Ford+Accessor.GetAmount()));

				tax.setText(iTax); //tax
				subTotal.setText(isubTotalString); //sub total
				total.setText(iTotal); //total
			}
			
			if (comboBox_CarBox.getSelectedItem().equals("Bmw") && car_trade.getSelectedItem().equals("50001 - 100000") ) {
				Bmw=Bmw-1200;
				String isubTotalString=String.format("$%.2f",Bmw+Accessor.GetAmount());
				String iTax=String.format("$%.2f",cFindTax(Bmw+Accessor.GetAmount()));
				String iTotal=String.format("$%.2f",Bmw+Accessor.GetAmount()+cFindTax(Ford+Accessor.GetAmount()));

				tax.setText(iTax); //tax
				subTotal.setText(isubTotalString); //sub total
				total.setText(iTotal); //total
			}
			
			if (comboBox_CarBox.getSelectedItem().equals("Porche") && car_trade.getSelectedItem().equals("50001 - 100000") ) {
				Porche=Porche-1200;
				String isubTotalString=String.format("$%.2f",Porche+Accessor.GetAmount());
				String iTax=String.format("$%.2f",cFindTax(Porche+Accessor.GetAmount()));
				String iTotal=String.format("$%.2f",Porche+Accessor.GetAmount()+cFindTax(Ford+Accessor.GetAmount()));

				tax.setText(iTax); //tax
				subTotal.setText(isubTotalString); //sub total
				total.setText(iTotal); //total
			}
			
			if (comboBox_CarBox.getSelectedItem().equals("Aston_Martin") && car_trade.getSelectedItem().equals("50001 - 100000") ) {
				Aston_Martin=Aston_Martin-1200;
				String isubTotalString=String.format("$%.2f",Aston_Martin+Accessor.GetAmount());
				String iTax=String.format("$%.2f",cFindTax(Aston_Martin+Accessor.GetAmount()));
				String iTotal=String.format("$%.2f",Aston_Martin+Accessor.GetAmount()+cFindTax(Ford+Accessor.GetAmount()));

				tax.setText(iTax); //tax
				subTotal.setText(isubTotalString); //sub total
				total.setText(iTotal); //total
			}
			
			/**
			 * car trade 100001 - 500000
			 */
			if (comboBox_CarBox.getSelectedItem().equals("Ford") && car_trade.getSelectedItem().equals("100001 - 500000") ) {
				Ford=Ford-250;
				String isubTotalString=String.format("$%.2f",Ford+Accessor.GetAmount());
				String iTax=String.format("$%.2f",cFindTax(Ford+Accessor.GetAmount()));
				String iTotal=String.format("$%.2f",Ford+Accessor.GetAmount()+cFindTax(Ford+Accessor.GetAmount()));

				tax.setText(iTax); //tax
				subTotal.setText(isubTotalString); //sub total
				total.setText(iTotal); //total
			}
			
			if (comboBox_CarBox.getSelectedItem().equals("Bmw") && car_trade.getSelectedItem().equals("100001 - 500000") ) {
				Bmw=Bmw-250;
				String isubTotalString=String.format("$%.2f",Bmw+Accessor.GetAmount());
				String iTax=String.format("$%.2f",cFindTax(Bmw+Accessor.GetAmount()));
				String iTotal=String.format("$%.2f",Bmw+Accessor.GetAmount()+cFindTax(Ford+Accessor.GetAmount()));

				tax.setText(iTax); //tax
				subTotal.setText(isubTotalString); //sub total
				total.setText(iTotal); //total
			}
			
			if (comboBox_CarBox.getSelectedItem().equals("Porche") && car_trade.getSelectedItem().equals("100001 - 500000") ) {
				Porche=Porche-250;
				String isubTotalString=String.format("$%.2f",Porche+Accessor.GetAmount());
				String iTax=String.format("$%.2f",cFindTax(Porche+Accessor.GetAmount()));
				String iTotal=String.format("$%.2f",Porche+Accessor.GetAmount()+cFindTax(Ford+Accessor.GetAmount()));

				tax.setText(iTax); //tax
				subTotal.setText(isubTotalString); //sub total
				total.setText(iTotal); //total
			}
			
			if (comboBox_CarBox.getSelectedItem().equals("Aston_Martin") && car_trade.getSelectedItem().equals("100001 - 500000") ) {
				Aston_Martin=Aston_Martin-250;
				String isubTotalString=String.format("$%.2f",Aston_Martin+Accessor.GetAmount());
				String iTax=String.format("$%.2f",cFindTax(Aston_Martin+Accessor.GetAmount()));
				String iTotal=String.format("$%.2f",Aston_Martin+Accessor.GetAmount()+cFindTax(Ford+Accessor.GetAmount()));

				tax.setText(iTax); //tax
				subTotal.setText(isubTotalString); //sub total
				total.setText(iTotal); //total
			}
			
			}
			
		});
		Total_btn.setForeground(Color.WHITE);
		Total_btn.setBackground(SystemColor.textHighlight);
		Total_btn.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		Total_btn.setBounds(30, 24, 150, 57);
		panel_2_1_1_1_1.add(Total_btn);
	}
	public double mcTax=0.9;
	public Double cFindTax(double cAmount) {
		double FinfTax=(cAmount*mcTax);
		return FinfTax;
	}
	
	/**
	 * Cost of car
	 */
	double Ford = 26500;
	double Bmw = 45000;
	double Porche = 57000;
	double Aston_Martin = 15800;
	
}
