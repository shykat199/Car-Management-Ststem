package car_management;

public class Car {
	
	/*
	 * Data Member
	 */
	
	private String fordString;
	private String bmwString;
	private String porcheString;
	private String aston_MartinString;
	
	
	private String trade_in_1="1 - 5000";
	private String trade_in_2="5001 - 20000";
	private String trade_in_3="20001 - 50000";
	private String trade_in_4="50001 - 100000";	
	private String trade_in_5="100001 - 500000";
	
	
	
	
	public String getFordString() {
		return fordString;
	}
	public void setFordString(String fordString) {
		this.fordString = fordString;
	}
	public String getBmwString() {
		return bmwString;
	}
	public void setBmwString(String bmwString) {
		this.bmwString = bmwString;
	}
	public String getPorcheString() {
		return porcheString;
	}
	public void setPorcheString(String porcheString) {
		this.porcheString = porcheString;
	}
	public String getAston_MartinString() {
		return aston_MartinString;
	}
	public void setAston_MartinString(String aston_MartinString) {
		this.aston_MartinString = aston_MartinString;
	}
	public String getTrade_in_1() {
		return trade_in_1;
	}
	public void setTrade_in_1(String trade_in_1) {
		this.trade_in_1 = trade_in_1;
	}
	public String getTrade_in_2() {
		return trade_in_2;
	}
	public void setTrade_in_2(String trade_in_2) {
		this.trade_in_2 = trade_in_2;
	}
	public String getTrade_in_3() {
		return trade_in_3;
	}
	public void setTrade_in_3(String trade_in_3) {
		this.trade_in_3 = trade_in_3;
	}
	public String getTrade_in_4() {
		return trade_in_4;
	}
	public void setTrade_in_4(String trade_in_4) {
		this.trade_in_4 = trade_in_4;
	}
	public String getTrade_in_5() {
		return trade_in_5;
	}
	public void setTrade_in_5(String trade_in_5) {
		this.trade_in_5 = trade_in_5;
	}



}
