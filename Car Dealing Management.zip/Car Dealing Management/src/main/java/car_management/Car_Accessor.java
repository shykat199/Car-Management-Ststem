package car_management;

public class Car_Accessor {
	
	//Data Member
	private double iStereor=103.49;
	private double Modifield=500.78;
	private double Customer=200.90;
	private double Leather=1003.90;
	private double Gps=180.29;
	public double AccessorCost;
	
	
	public double getiStereor() {
		return iStereor;
	}
	public void setiStereor(double iStereor) {
		this.iStereor = iStereor;
	}
	public double getModifield() {
		return Modifield;
	}
	public void setModifield(double modifield) {
		Modifield = modifield;
	}
	public double getCustomer() {
		return Customer;
	}
	public void setCustomer(double customer) {
		Customer = customer;
	}
	public double getLeather() {
		return Leather;
	}
	public void setLeather(double leather) {
		Leather = leather;
	}
	public double getGps() {
		return Gps;
	}
	public void setGps(double gps) {
		Gps = gps;
	}
	

	public double GetAmount() {
		AccessorCost=iStereor+Modifield+Customer+Leather+Gps;
		return AccessorCost;
	}
	
}
